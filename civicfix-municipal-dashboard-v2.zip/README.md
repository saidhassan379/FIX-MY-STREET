# CivicFix Municipal Dashboard — Contract-Compatible Frontend

This frontend is ENI's municipal dashboard component only.

## Shared-contract compatibility
The frontend:
- uses the exact shared report field names:
  report_id, photo, latitude, longitude, description, category, confidence,
  severity, safety_risk, possible_duplicate, department, status, created_at, status_history
- uses the exact shared status values:
  REPORTED, VERIFIED, ASSIGNED, INVESTIGATING, SCHEDULED, RESOLVED
- uses the exact supported AI category values in its data model
- does not contain Gemini, database, Auth0, API-key, deployment, QR, or backend configuration
- does not implement department-routing logic
- keeps status updates as a municipal UI action; persistence/API connection is left for the technical/integration layer

## Input expected from the shared backend
A report object matching the shared field names above.

## Output/action
The municipal UI displays the report and emits a status change in the selected report object. The integration/backend layer should persist that change and return the updated report/status_history.

## Run
Open index.html in a browser.
